package com.sb.demo;

public class AccountMapper {
   public static Account maptoAccount(AccountDto accountdto)
   {   Account account =new Account(
		   accountdto.getId(),
		   accountdto.getAccountholder(),
		   accountdto.getBalance()
		   );
   return account;

   }
   public static AccountDto maptoAccountDto(Account account)
   {    AccountDto accountdto=new AccountDto(
		   account.getId(),
		   account.getAccountholder(),
		   account.getBalance()
		   );
   
	   return accountdto;
   }
}  
