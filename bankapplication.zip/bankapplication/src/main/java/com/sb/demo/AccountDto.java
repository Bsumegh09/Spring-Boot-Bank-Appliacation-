package com.sb.demo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountDto {
           private long id;
           
           @JsonProperty("Accountholder")
           private String accountholder;
          
           private double balance;
}
