package com.sb.demo;

import java.util.List;

public interface AccountService {
        AccountDto CreateAccount(AccountDto accountdto);

		AccountDto getAccountByid(Long id);
		AccountDto deposite(Long id ,double amount);
		AccountDto withdraw(Long id ,double amount);
        List<AccountDto>getAllAccount();
        void deleteAccount(Long id);
}
