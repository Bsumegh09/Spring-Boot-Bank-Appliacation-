package com.sb.demo;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class Accountimp  implements AccountService{
    private AccountRepo accountrepo;
	public Accountimp(AccountRepo accountrepo) {
	
		this.accountrepo = accountrepo;
	}
	@Override
	public AccountDto CreateAccount(AccountDto accountdto) {
		// TODO Auto-generated method stub
		Account account=AccountMapper.maptoAccount(accountdto);
		Account savedAccount=accountrepo.save(account);
		
		return AccountMapper.maptoAccountDto(savedAccount);
	}
	@Override
	public AccountDto getAccountByid(Long id)
	{
		Account account = accountrepo
				.findById(id)
				.orElseThrow(()->new RuntimeException("Account Not Found"));
		return AccountMapper.maptoAccountDto(account);
	}
	@Override
	public AccountDto deposite(Long id, double amount) {
		Account account = accountrepo
				.findById(id)
				.orElseThrow(()->new RuntimeException("Account Not Found"));
		double total=account.getBalance()+amount;
		account.setBalance(total);
		Account savedAccount=accountrepo.save(account);
		return AccountMapper.maptoAccountDto(savedAccount);
	}
	@Override
	public AccountDto withdraw(Long id, double amount) {
		// TODO Auto-generated method stub
		Account account = accountrepo
				.findById(id)
				.orElseThrow(()->new RuntimeException("Account Not Found"));
		
		if(account.getBalance()<amount) {
			throw new RuntimeException(" Insufficient Amount");
		}
		
		double total=account.getBalance() - amount;
		account.setBalance(total);
		Account savedAccount=accountrepo.save(account);
		return AccountMapper.maptoAccountDto(savedAccount);
	}
	@Override
	public List<AccountDto> getAllAccount() {
		// TODO Auto-generated method stub
		List<Account> accounts=accountrepo.findAll();
		return accounts.stream().map((account)->AccountMapper.maptoAccountDto(account))
		.collect(Collectors.toList());
		
	}
	// Deleting 
	@Override
	public void deleteAccount(Long id) {
		Account account = accountrepo
				.findById(id)
				.orElseThrow(()->new RuntimeException("Account Not Found"));
		accountrepo.deleteById(id);
		
	}

}
